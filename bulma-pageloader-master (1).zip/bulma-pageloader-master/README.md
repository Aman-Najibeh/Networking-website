# bulma-pageloader
Bulma's extension to show a page loader overlay of the whole page.
(find all my bulma's extensions [here](https://wikiki.github.io/))

[![npm](https://img.shields.io/npm/v/bulma-pageloader.svg)](https://www.npmjs.com/package/bulma-pageloader)
[![npm](https://img.shields.io/npm/dm/bulma-pageloader.svg)](https://www.npmjs.com/package/bulma-pageloader)
[![Build Status](https://travis-ci.org/Wikiki/bulma-pageloader.svg?branch=master)](https://travis-ci.org/Wikiki/bulma-pageloader)

Overview
---
![Pageloader Element](https://img15.hostingpics.net/pics/217768bulmapageloader.gif)

To get the page-loader displayed, add `is-active` class to the pageloader element.

Documentation & Demo
---
You can find the Documentation and a demo [here](https://wikiki.github.io/elements/pageloader/)
